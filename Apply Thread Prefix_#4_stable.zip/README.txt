## INFORMATION ##

Apply Thread Prefix (1.3) for MyBB 1.8
Created by: Starpaul20
Copyright: �2011
License: GPL

Allows moderators to apply a thread prefix to thread(s) without having to edit the first post of that thread.

To use, you just select the Apply Thread Prefix option from the Moderation Options menu in a thread or from the Inline Thread Moderation in a forum, select the desired prefix (please note no menu will show up if there are no prefixes available for that forum) and click Apply Thread Prefix. Whenever prefixes are applied, the action is logged in the Moderator Log.

This plugin offers full language support.

The 'oldrelease' branch contains the 1.6 version of the plugin.


## INSTALLATION ##

1. Upload all files above, keeping the file structure intact.
2. Go to Configuration > Plugins
3. Click "Activate"
4. Enjoy!


## UPDATING ##

If you're updating from any previous version, you must first deactivate the plugin, upload all new files and reactivate.
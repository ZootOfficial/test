# [ETS] Threadlist Filter Prefix
#### Plug-in for MyBB forum system
Displays a selection to filter thread list by prefixes with additional options and styling.  
Efficient code and optimized processing without redudancy in calling methods.  
Multilingual plug-in using language files and embedded scalable vectors (SVG).

---

## Plugin options and settings in ACP:
- Enable/Disable filter
- Set filter for specific user groups
- Set filter for specific forums
- Set build-in styling
- Show caption (optional)
- Show reset button (optional)
- Show thread count (optional)
- Define own CSS classes for link buttons (optional)

## Build-in stylings:
1. Plain Text
2. Defined Prefix Style
3. Button Style
4. Navigation Style
5. Pagination Style
6. Postbit Button Style
7. Head Link Style (thead)
8. Foot Link Style (tfoot)
9. Category Link Style (tcat)
10. Drop-Down Select

## Preset classes for more granular CSS styling
- .ets_tfp			(Wrapping element)
- .ets_tfp .caption	(Caption element)
- .ets_tfp .reset	(Reset link element)
- .ets_tfp .num		(Count of threads)
- .ets_tfp .active	(Any active link element (Mind: select options auto-marked as selected instead))
- .ets_tfp a		(Any prefix link)

## Installation
Copy the script and language files of this package into correspond directories of your forum installation and activate this plug-in in ACP.

## Template modification
- Modified template:
  - forumdisplay_threadlist
- Adding variable to top of thread list:
  (This variable can be placed inside template to wherever the filter should appear)
  - {$ets_filter_prefix}

---

# Changelog
- Changes made from v1.0 to v1.1:
  - Code improvements in allowing specific usergroups or forums (no operational change)
- Changes made from v1.1 to v1.2:
  - Minor correction in German translation (language variable mismatch) (no operational change)
  - Put the count of threads in parenthesis (brackets) as an additional option

---

# Plugin/Author Details
#### MyBB Plug-In:
[ETS] Threadlist Filter Prefix
#### Version:
1.0 (stable)
1.1 (stable)
1.2 (stable)
#### Ident:
ets_tfp
#### Description:
Displays a selection to filter thread list by prefixes with additional options and styling.
#### License:
Free Software under GNU GPLv3 (General Public License)
#### Author:
(c)2021 [ExiTuS], Thorsten Wernicke (wernicke.me)
#### MyBB Community Contact:
- EN: https://community.mybb.com/user-128511.html
- DE: https://www.mybb.de/forum/user-11096.html

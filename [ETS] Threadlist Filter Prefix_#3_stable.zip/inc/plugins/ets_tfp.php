<?php
/*
 * MyBB Plug-In		[ETS] Threadlist Filter Prefix
 * Version			1.2 (stable)
 * Ident			ets_tfp
 * Description		Displays buttons to filter thread list by prefixes with additional options and styling.
 * Copyright		(c)2021 [ExiTuS], Thorsten Wernicke (wernicke.me)
 * License			Free Software under GNU GPL (General Public License)
 * MyBB Community Contact
 *					EN:	https://community.mybb.com/user-128511.html
 *					DE:	https://www.mybb.de/forum/user-11096.html
 */

if(!defined("IN_MYBB")) die("Access forbidden.");

$plugins->add_hook('forumdisplay_threadlist', 'ets_tfp_run');

function ets_tfp_info() {
	global $lang;
	$lang->load("ets_tfp");
	return [
		"name"			=> $lang->ets_tfp_name,
		"description"	=> $lang->ets_tfp_desc,
		"website"		=> "https://community.mybb.com/user-128511.html",
		"author"		=> "[ExiTuS]",
		"authorsite"	=> "https://wernicke.me",
		"version"		=> "1.2",
		"codename"		=> "ets_tfp",
		"guid"			=> "",
		"compatibility"	=> "18*"
	];
}

function ets_tfp_activate() {
	global $mybb, $db, $lang;
	require_once MYBB_ROOT.'inc/adminfunctions_templates.php';
	$lang->load("ets_tfp");
	find_replace_templatesets("forumdisplay_threadlist", "#^#i", "{\$ets_filter_prefix}\r\n");
	#find_replace_templatesets('forumdisplay_threadlist', '#{\$newthread}(\r?)\n#', "{\$newthread}\n{\$ets_prefix_filter}\n");

	$settings_group = [
		"name"			=> "ets_tfp",
		"title"			=> $lang->ets_tfp_name,
		"description"	=> $lang->ets_tfp_cfg_desc,
		"disporder"		=> "901",
		"isdefault"		=> "0"
	];
	$db->insert_query("settinggroups", $settings_group);
    $gid = $db->insert_id();
	$setting[] = [
		"name"			=> "ets_tfp_enable",
		"title"			=> $lang->ets_tfp_cfg_enable,
		"description"	=> $lang->ets_tfp_cfg_enable_desc,
		"optionscode"	=> "yesno",
		"value"			=> "1",
		"disporder"		=> 1,
		"gid"			=> intval($gid)
	];
	$setting[] = [
		"name"			=> "ets_tfp_groups",
		"title"			=> $lang->ets_tfp_cfg_users,
		"description"	=> $lang->ets_tfp_cfg_users_desc,
		"optionscode"	=> "groupselect",
		"value"			=> "-1",
		"disporder"		=> 2,
		"gid"			=> intval($gid)
	];
	$setting[] = [
		"name"			=> "ets_tfp_forums",
		"title"			=> $lang->ets_tfp_cfg_forums,
		"description"	=> $lang->ets_tfp_cfg_forums_desc,
		"optionscode"	=> "forumselect",
		"value"			=> "-1",
		"disporder"		=> 3,
		"gid"			=> intval($gid)
	];
	$setting[] = [
		"name"			=> "ets_tfp_style",
		"title"			=> $lang->ets_tfp_cfg_style,
		"description"	=> $lang->ets_tfp_cfg_style_desc,
		"optionscode"	=> "select\ntxt=Plain Text\ndef=Defined Prefix Style\nbut=Button Style\nnav=Navigation Style\npag=Pagination Style\npos=Postbit Button Style\nthd=Head Link Style (thead)\ntft=Foot Link Style (tfoot)\ntct=Category Link Style (tcat)\nsel=Drop-Down Select",
		"value"			=> "def",
		"disporder"		=> 4,
		"gid"			=> intval($gid)
	];
	$setting[] = [
		"name"			=> "ets_tfp_class",
		"title"			=> $lang->ets_tfp_cfg_class,
		"description"	=> $lang->ets_tfp_cfg_class_desc,
		"optionscode"	=> "text",
		"value"			=> "",
		"disporder"		=> 5,
		"gid"			=> intval($gid)
	];
	$setting[] = [
		"name"			=> "ets_tfp_caption",
		"title"			=> $lang->ets_tfp_cfg_caption,
		"description"	=> $lang->ets_tfp_cfg_caption_desc,
		"optionscode"	=> "yesno",
		"value"			=> "1",
		"disporder"		=> 6,
		"gid"			=> intval($gid)
	];
	$setting[] = [
		"name"			=> "ets_tfp_reset",
		"title"			=> $lang->ets_tfp_cfg_reset,
		"description"	=> $lang->ets_tfp_cfg_reset_desc,
		"optionscode"	=> "yesno",
		"value"			=> "1",
		"disporder"		=> 7,
		"gid"			=> intval($gid)
	];
	$setting[] = [
		"name"			=> "ets_tfp_count",
		"title"			=> $lang->ets_tfp_cfg_count,
		"description"	=> $lang->ets_tfp_cfg_count_desc,
		"optionscode"	=> "yesno",
		"value"			=> "1",
		"disporder"		=> 8,
		"gid"			=> intval($gid)
	];
	$setting[] = [
		"name"			=> "ets_tfp_count_p",
		"title"			=> $lang->ets_tfp_cfg_count_p,
		"description"	=> $lang->ets_tfp_cfg_count_p_desc,
		"optionscode"	=> "yesno",
		"value"			=> "0",
		"disporder"		=> 9,
		"gid"			=> intval($gid)
	];
 	foreach($setting as $i) {
		$db->insert_query("settings", $i);
	}
	rebuild_settings();
}

function ets_tfp_deactivate() {
	global $mybb, $db, $lang;
	require_once MYBB_ROOT.'inc/adminfunctions_templates.php';
	$lang->load("ets_tfp");
	find_replace_templatesets("forumdisplay_threadlist", "#" . preg_quote('{$ets_filter_prefix}') . "\r\n#i", "", 0);
	$db->query("DELETE FROM ".TABLE_PREFIX."settinggroups WHERE name='ets_tfp'");
	$db->delete_query("settings", "name IN ('ets_tfp_enable', 'ets_tfp_groups', 'ets_tfp_forums', 'ets_tfp_style', 'ets_tfp_class', 'ets_tfp_caption', 'ets_tfp_reset', 'ets_tfp_count', 'ets_tfp_count_p')");
	rebuild_settings();
}

function ets_tfp_run() {
	global $mybb, $db, $fid, $lang, $ets_filter_prefix;

	if($mybb->settings['ets_tfp_enable'] == "1") {

		$lang->load("ets_tfp");

		# Check forums and groups allowed
		$frm_display = $mybb->settings['ets_tfp_forums'];
		if(($frm_display == "-1" || in_array($fid, explode(',', $frm_display))) && is_member($mybb->settings['ets_tfp_groups'])) {

			# User/Moderator permissions
			$ets_sql_vis = "1";
			if(is_moderator($fid, "canviewunapprove")) $ets_sql_vis .= ",-1";
			if(is_moderator($fid, "canviewdeleted"))   $ets_sql_vis .= ",0";
			
			$sql_visible = " AND t.visible IN(" . $ets_sql_vis . ")";
			if($mybb->user['uid'] && $mybb->settings['showownunapproved']) $sql_visible .= " OR (t.visible = 0 AND t.uid=" . (int)$mybb->user['uid'] . ")";

			# Query prefixes
			$sql = "SELECT p.pid AS p_pid, p.prefix AS p_prefix, p.displaystyle AS p_style, COUNT(p.pid) AS p_count
					FROM " . TABLE_PREFIX . "threads t
					INNER JOIN " . TABLE_PREFIX . "threadprefixes p ON p.pid = t.prefix
					WHERE t.fid = $fid AND t.prefix != 0 $sql_visible
					GROUP BY t.prefix;";

			$ets_sql_res = $db->query($sql);
			$ets_num_row = $db->num_rows($ets_sql_res);

			if($ets_num_row > 0) {

				$ets_tfp_inp = $mybb->get_input('prefix', MyBB::INPUT_INT);
				$ets_tfp_cnt = ($mybb->settings['ets_tfp_count'] != "0") ? true : false;
				$ets_tfp_cnt_p = ($mybb->settings['ets_tfp_count_p'] != "0") ? true : false;

				# Own class defined, else selected style
				$ets_tfp_cls_def = $mybb->settings['ets_tfp_class'];
				if($ets_tfp_cls_def != '') $ets_tfp_cls = $ets_tfp_cls_def;
				else {
					$ets_tfp_cls_act = '';
					$ets_tfp_cls_cnt = 'ets_tfp';

					switch($mybb->settings['ets_tfp_style']) {
					case 'sel':
						$ets_tfp_sel = true;
						break;
					case 'def':
						$ets_tfp_def = true;
						break;
					case 'but':
						$ets_tfp_cls = 'button';
						break;
					case 'pos':
						$ets_tfp_cls_cnt .= ' postbit_buttons';
						break;
					case 'nav':
						$ets_tfp_cls_act = 'navigation_active';
						$ets_tfp_cls_cnt .=  ' navigation';
						break;
					case 'pag':
						$ets_tfp_pag = true;
						$ets_tfp_cls = 'pagination_page';
						$ets_tfp_cls_act = 'pagination_current';
						$ets_tfp_cls_cnt .= ' pagination';
						break;
					case 'thd':
						$ets_tfp_cls_cnt .= ' thead';
						break;
					case 'tft':
						$ets_tfp_cls_cnt .= ' tfoot';
						break;
					case 'tct':
						$ets_tfp_cls_cnt .= ' tcat';
						break;
					}
				}

				# Open container or form
				$ets_filter_prefix .= ($ets_tfp_sel) ? "\n<form class=\"ets_tfp\" action=\"" . $mybb->settings['bburl'] . "/forumdisplay.php\" method=\"get\">\n<input type=\"hidden\" name=\"fid\" value=\"" . $fid . "\">" : "\n<span class=\"" . $ets_tfp_cls_cnt . "\">";

				# Display caption if enabled
				$ets_filter_prefix .= ($mybb->settings['ets_tfp_caption'] != "0") ? "\n<span class=\"" . (($ets_tfp_pag) ? "pages" : "") . " caption\">" . $lang->ets_tfp_caption . "</span>" : "";

				# Open select
				$ets_filter_prefix .= ($ets_tfp_sel) ? "\n<select name=\"prefix\">" : "";

				# Build prefix elements
				while ($row = $db->fetch_array($ets_sql_res)) {
					$ets_tfp_act = ($ets_tfp_inp == $row['p_pid']) ? true : false;
					$ets_tfp_dsp = ($ets_tfp_def) ? $row['p_style'] : $row['p_prefix'];
					$ets_tfp_num = ($ets_tfp_cnt) ? "\n<span class=\"num\">" . (($ets_tfp_cnt_p) ? "(" . $row['p_count'] . ")" : $row['p_count']) . "</span>" : "";

					# Build select options or links
					$ets_filter_prefix .= ($ets_tfp_sel) ? "\n<option value=\"" . $row['p_pid'] . "\"" . (($ets_tfp_act) ? " selected=\"selected\"" : "") . ">" . $row['p_prefix'] . ( ($ets_tfp_cnt) ? " (" . $row['p_count'] . ")" : "") . "</option>" : (($ets_tfp_act && $ets_tfp_cls_act != '') ? "\n<span class=\"" . $ets_tfp_cls_act . " active\">" . $ets_tfp_dsp . $ets_tfp_num . "</span>" : "\n<a class=\"" . $ets_tfp_cls . (($ets_tfp_act) ? " active" : "") . "\" href=\"" . $mybb->settings['bburl'] . "/forumdisplay.php?fid=" . $fid . "&prefix=" . $row['p_pid'] . "\">" . $ets_tfp_dsp . $ets_tfp_num . "</a>");
				}

				# Close select
				$ets_filter_prefix .= ($ets_tfp_sel) ? "\n</select>\n<input type=\"submit\" class=\"button\" value=\"" . $lang->go . "\">" : "";

				# Display reset button if enabled if any filter selected
				$ets_filter_prefix .= ($ets_tfp_inp > 0 && $mybb->settings['ets_tfp_reset'] != "0") ? "\n<a class=\"" . $ets_tfp_cls . " reset\" href=\"" . $mybb->settings['bburl'] . "/forumdisplay.php?fid=" . $fid . "\" title=\"" . $lang->ets_tfp_reset . "\">" . $lang->ets_tfp_reset_x . "</a>" : "";

				# Close form or container
				$ets_filter_prefix .= ($ets_tfp_sel) ? "\n</form>" : "\n</span>";
			}
		}
	}
}
<?php
$l['ets_tfp_name']				= "[ETS] Threadlist Filter Prefix";
$l['ets_tfp_desc']				= "Zeigt einen Präfix-Filter in der Themenübersicht.";
$l['ets_tfp_caption']			= "Filter:";
$l['ets_tfp_reset']				= "Zurücksetzen";
$l['ets_tfp_reset_x']			= "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 100 100\" style=\"height: 1em;\"><polyline stroke=\"#C00\" points=\"20,20 80,80\" stroke-width=\"10\"></polyline><polyline stroke=\"#C00\" points=\"80,20 20,80\" stroke-width=\"10\"></polyline></svg>";
